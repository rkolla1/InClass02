package com.example.chatroom.Fragments;

import android.app.AlertDialog;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.example.chatroom.Adapter.Chat_Adapter;
import com.example.chatroom.Chat_room;
import com.example.chatroom.R;
import com.example.chatroom.User;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


public class Chat_Fragment extends Fragment {

    private RecyclerView recycler;
    private RecyclerView.LayoutManager layout;
    private Chat_Adapter chatAdapter;
    private ArrayList<Chat_room> chat_group;
    FirebaseDatabase database;
    DatabaseReference myref;
    DatabaseReference myref1;
    Chat_room chat_room;
    FirebaseUser firebaseUser;
    User user;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        database=FirebaseDatabase.getInstance();
        myref=database.getReference("chat_groups");
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        System.out.println(("user_name "+firebaseUser.getEmail()+""));

        View view = inflater.inflate(R.layout.fragment_chat_, container, false);
        view.findViewById(R.id.floatingActionButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                System.out.println("Status"+" "+"inside floatingaction");
                LayoutInflater inflater = getLayoutInflater();
                View dialogView=inflater.inflate(R.layout.layout,null);
                builder.setView(dialogView);
                final EditText ed1 = dialogView.findViewById(R.id.edit_text_dialog);
                final AlertDialog dialog=builder.create();
                dialog.show();
                dialogView.findViewById(R.id.btn_dialog).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        System.out.println("inside on click");
                        if(TextUtils.isEmpty(ed1.getText().toString())){
                            ed1.setError("enter the name");
                        }
                        else{
                            System.out.println("Inside else condition");
                            chat_room = new Chat_room();
                            chat_room.name=ed1.getText().toString();
                            Log.d("User_id",firebaseUser.getUid());
                            user=new User();
                            user.email=firebaseUser.getEmail();
                           myref.child(chat_room.name).setValue(chat_room);
                           myref.child(chat_room.name).child("users").child(firebaseUser.getUid()).setValue(firebaseUser.getEmail());
                            //myref1=myref.child("users");
                            //myref1.child("users").setValue(firebaseUser.getUid());


                           System.out.println("finished adding the data");
                            dialog.dismiss();
                        }
                    }
                });


            }
        });
        recycler = view.findViewById(R.id.recyclerview_chatfragment);
        recycler.setHasFixedSize(true);
        layout = new LinearLayoutManager(getContext());
        recycler.setLayoutManager(layout);
        chat_group = new ArrayList<Chat_room>();
        read_chatrooms();

        return view;
    }
    private void read_chatrooms(){
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("chat_groups");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                chat_group.clear();
                for (DataSnapshot snapshot:dataSnapshot.getChildren()){
                    Chat_room chat_room=snapshot.getValue(Chat_room.class);
                    Log.d("Chat_room",chat_room.toString());
                    chat_group.add(chat_room);
                }
                chatAdapter=new Chat_Adapter(chat_group,getContext());
                recycler.setAdapter(chatAdapter);
                //recycler.setVisibility(View.INVISIBLE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}


