package com.example.chatroom.Adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.chatroom.MessageActivity;
import com.example.chatroom.R;
import com.example.chatroom.Users;

import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.ViewHolder> {

    private Context context;
    private List<Users> musers;

    public UserAdapter(Context context,List<Users> musers){
        this.context = context;
        this.musers = musers;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.users_item,viewGroup,false);
        return new UserAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, final int i) {

        final Users users = musers.get(i);
        viewHolder.username.setText(users.getUsername());
        viewHolder.profileimage.setImageResource(R.mipmap.ic_launcher);
        //if(users.getImageUrl().equals("default")){
           // viewHolder.profileimage.setImageResource(R.mipmap.ic_launcher);
        //}else{
            //Glide.with(context).load(users.getImageUrl()).into(viewHolder.profileimage);
        //}

        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, MessageActivity.class);
                intent.putExtra("userid", users.getId());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return musers.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder{

        public TextView username;
        public ImageView profileimage;

        public ViewHolder(View itemView) {
            super(itemView);

            username = itemView.findViewById(R.id.username_users_item);
            profileimage = itemView.findViewById(R.id.profile_image);

        }
    }

}
