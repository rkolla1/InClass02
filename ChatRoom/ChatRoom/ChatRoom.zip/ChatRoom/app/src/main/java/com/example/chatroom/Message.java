package com.example.chatroom;

import java.io.Serializable;
import java.util.ArrayList;

public class Message implements Serializable {
    String sender_name;
    int likes_count;
    String sender_email;
}
