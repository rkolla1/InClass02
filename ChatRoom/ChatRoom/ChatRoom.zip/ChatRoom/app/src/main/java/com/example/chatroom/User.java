package com.example.chatroom;

public class User {
    public String email;
    public User(){
    }
}
